// src/App.jsx
import React from 'react';
import Team from './components/Team';

function App() {
  return (
    <div>
      <Team />
    </div>
  );
}

export default App;
