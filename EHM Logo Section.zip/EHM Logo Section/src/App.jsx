import React  from 'react';

import LogoSection from './Component/logoSection';

const App = () => {
  return (
    <div>
      <LogoSection />
    </div>
  );
};
export default App