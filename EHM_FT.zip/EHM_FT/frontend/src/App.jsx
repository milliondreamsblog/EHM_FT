import React from 'react'
import ProductShowcase from './Component/ProductShowcase'

const App = () => {
  return (
    <div>
      <ProductShowcase />
      
    </div>
  )
}

export default App
